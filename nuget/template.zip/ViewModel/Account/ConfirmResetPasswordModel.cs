using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using vlko.core.ValidationAtribute;

namespace $safeprojectname$.ViewModel.Account
{
    [PropertiesMustMatch("NewPassword", "ConfirmPassword", ErrorMessage = "The new password and confirmation password do not match.")]
    public class ConfirmResetPasswordModel
    {
        [Required]
        public string Username { get; set; }

        [Required]
        public string VerifyToken { get; set; }

        [Required]
        [ValidatePasswordLength]
        [DataType(DataType.Password)]
        [DisplayName("New password")]
        public string NewPassword { get; set; }

        [Required]
        [DataType(DataType.Password)]
        [DisplayName("Confirm new password")]
        public string ConfirmPassword { get; set; }
    }
}
